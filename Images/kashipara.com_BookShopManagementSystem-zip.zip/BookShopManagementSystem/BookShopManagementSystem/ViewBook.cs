﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BookShopManagementSystem
{
    public partial class ViewBook : Form
    {
        public ViewBook()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\n\documents\visual studio 2010\Projects\BookShopManagementSystem\BookShopManagementSystem\book.mdf;Integrated Security=True;User Instance=True");             
            con.Open();
            if (textBox1.Text != "")
            {
                try
                {
                    string getCust = "select title,edition,author,ISBN,publisher,category,price,stock from Books where book_id=" + Convert.ToInt32(textBox1.Text) + " ;";    

                    SqlCommand cmd = new SqlCommand(getCust, con);
                    SqlDataReader dr;
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        label11.Text = dr.GetValue(0).ToString();
                        label12.Text = dr.GetValue(1).ToString();
                        label13.Text = dr.GetValue(2).ToString();
                        label14.Text = dr.GetValue(3).ToString();
                        label15.Text = dr.GetValue(4).ToString();
                        label16.Text = dr.GetValue(5).ToString();
                        label17.Text = dr.GetValue(6).ToString();
                        label18.Text = dr.GetValue(7).ToString();    
                    }
                    else
                    {
                        MessageBox.Show(" *** Sorry !! This ID, " + textBox1.Text + " is INVALID. Please Check Book Id..  ***  ");
                        textBox1.Text = "";
                    }
                }
                catch (SqlException excep)
                {
                    MessageBox.Show(excep.Message);
                }
                con.Close();
            }

        }
    }
}
